#include <Arduino.h>
#include <dht.h>
#include <SD.h>
#include <Time.h>
#include <Wire.h>
#include <DS1307RTC.h>
float MGRead(int mg_pin);
int  MGGetPercentage(float volts, float *pcurve);
String getParam();
String getDigits(int digits);
void setup();
void loop();
#line 1 "src/sketch.ino"
//
//    FILE: dht22_test.ino
//  AUTHOR: Rob Tillaart
// VERSION: 0.1.03
// PURPOSE: DHT library test sketch for DHT22 && Arduino
//     URL:
// HISTORY:
// 0.1.03 extended stats for all errors
// 0.1.02 added counters for error-regression testing.
// 0.1.01
// 0.1.00 initial version
//
// Released to the public domain
//
          
/*
 * SD карта подключается так:
 ** MOSI - пин 11
 ** MISO - пин 12
 ** CLK - пин 13
 ** CS - пин 4
*/
//#include <dht.h>
 
//#include <SD.h>
//#include <Time.h>
//#include <Wire.h>
//#include <DS1307RTC.h>

dht DHT;

/************************Hardware Related Macros************************************/
#define         MG_PIN                       (1)     //define which analog input channel you are going to use
#define         BOOL_PIN                     (2)
#define         DC_GAIN                      (8.5)   //define the DC gain of amplifier
 
 
/***********************Software Related Macros************************************/
#define         READ_SAMPLE_INTERVAL         (50)    //define how many samples you are going to take in normal operation
#define         READ_SAMPLE_TIMES            (5)     //define the time interval(in milisecond) between each samples in 
                                                     //normal operation
 
/**********************Application Related Macros**********************************/
//These two values differ from sensor to sensor. user should derermine this value.
#define         ZERO_POINT_VOLTAGE           (0.605) //define the output of the sensor in volts when the concentration of CO2 is 400PPM
#define         REACTION_VOLTGAE             (0.20) //define the voltage drop of the sensor when move the sensor from air into 1000ppm CO2
 

#define DHT22_PIN 7
/*****************************Globals***********************************************/
float           CO2Curve[3]  =  {2.602,ZERO_POINT_VOLTAGE,(REACTION_VOLTGAE/(2.602-3))};   
                                                     //two points are taken from the curve. 
                                                     //with these two points, a line is formed which is
                                                     //"approximately equivalent" to the original curve.
                                                     //data format:{ x, y, slope}; point1: (lg400, 0.324), point2: (lg4000, 0.280) 
                                                     //slope = ( reaction voltage ) / (log400 –log1000) 
 
 
File myFile;
int incomingByte = 0;  
 
/*****************************  MGRead *********************************************
Input:   mg_pin - analog channel
Output:  output of SEN-000007
Remarks: This function reads the output of SEN-000007
************************************************************************************/
float MGRead(int mg_pin)
{
    int i;
    float v=0;
 
    for (i=0;i<READ_SAMPLE_TIMES;i++) {
        v += analogRead(mg_pin);
        delay(READ_SAMPLE_INTERVAL);
    }
    v = (v/READ_SAMPLE_TIMES) *5.07/1024 ;
    return v;  
}
 
/*****************************  MQGetPercentage **********************************
Input:   volts   - SEN-000007 output measured in volts
         pcurve  - pointer to the curve of the target gas
Output:  ppm of the target gas
Remarks: By using the slope and a point of the line. The x(logarithmic value of ppm) 
         of the line could be derived if y(MG-811 output) is provided. As it is a 
         logarithmic coordinate, power of 10 is used to convert the result to non-logarithmic 
         value.
************************************************************************************/
int  MGGetPercentage(float volts, float *pcurve)
{
   if ((volts/DC_GAIN )>=ZERO_POINT_VOLTAGE) {
      return -1;
   } else { 
      return pow(10, ((volts/DC_GAIN)-pcurve[1])/pcurve[2]+pcurve[0]);
   }
}

String getParam(){
    String re;
    while (Serial.available()) {
        re.concat((char) Serial.read());
    }
    return re;
}
String getDigits(int digits){
   String re;

   // Функция для красивого вывода времени. Выводит ноль перед
   // односимвольными числами. "5" будет выведено как "05"

   re.concat(":");
   if(digits < 10){
	   re.concat("0");
   }
   re.concat(digits);

   return re;
}

struct
{
    uint32_t total;
    uint32_t ok;
    uint32_t crc_error;
    uint32_t time_out;
    uint32_t connect;
    uint32_t ack_l;
    uint32_t ack_h;
    uint32_t unknown;
} stat = { 0,0,0,0,0,0,0,0};

void setup()
{

    Serial.begin(9600);




    Serial.println("dht22_test.ino");
    Serial.print("LIBRARY VERSION: ");
    Serial.println(DHT_LIB_VERSION);
    Serial.println();
    Serial.println("Type,\tstatus,\tHumidity (%),\tTemperature (C)\tTime (us)");
    pinMode(BOOL_PIN, INPUT);                        //set pin to input
    digitalWrite(BOOL_PIN, HIGH);                    //turn on pullup resistors
 


   Serial.print("MG-811 Demostration\n");                

  Serial.print("Initializing SD card...");
  // Магия. Этот вывод должен быть настроен как выход.
  // Иначе, некоторые функции могут не работать.
   pinMode(10, OUTPUT);
 
  if (!SD.begin(4)) {
    Serial.println("initialization failed!");
    return;
  }
  Serial.println("initialization done.");


 
    // Ждём, пока запустится последовательный порт
   // Устанавливаем функцию для получения времени с часов
   setSyncProvider(RTC.get);
   //Библиотека не получает время с часов каждый раз.
   //Задаётся функция для подключения к модулю часов
   //Библиотека получает с модуля время один раз
   //и далее ведёт отсчёт по внутренним часам Arduino,
   //синхронизируясь с часами по мере необходимости
   if(timeStatus()!= timeSet)
	  Serial.println("Unable to sync with the RTC");
   else
	  Serial.println("RTC has set the system time");
  if (SD.exists("log2.csv")) {
    Serial.println("log2.csv exists.");
  }
  else {
    Serial.println("log2.csv doesn't exist.");
  }
 
  //Откроем новый файл и сразу же закроем его:
  Serial.println("Creating log2.csv...");
  myFile = SD.open("log2.csv", FILE_WRITE);
  myFile.close();
 
  //Проверяем, создан ли файл:
  if (SD.exists("log2.csv")) {
    Serial.println("log2.csv exists.");
  }
  else {
    Serial.println("log2.csv doesn't exist.");
  }

	  File myFile2 = SD.open("log3.csv", FILE_WRITE);

	  // Если файл открылся, пишем в него:
	  if (myFile2) {
	    Serial.print("Writing to log3.csv...");
	   //Последовательно выводит часы, минуты, секунды
	   myFile.print("time");
//	   myFile.print(",");
//	   myFile.print("CO2");
//	   myFile.print(",");
//	   myFile.print("t");
//	   myFile.print(",");
//	   myFile.println("g");
	    myFile2.close();
	  } else {
	    // если файл не открылся, сообщает об ошибке:
	    Serial.println("error opening csv.log");
	  }

}

void loop()
{
	if (Serial.available()) { 
		String param = getParam();
		 Serial.print("string:");
		 Serial.print(param);
		 Serial.print(".");
		if (param == "log\n") {
			  // открываем файл только для чтения
			  myFile = SD.open("log2.csv");
			  if (myFile) {
			    Serial.println("log2.csv:");
			 
			    // читаем файл посимвольно до конца:
			    while (myFile.available()) {
			        Serial.write(myFile.read());
			    }
			    // закрываем файл:
			    myFile.close();
			  } else {
			    // если файл не открылся, сообщает об ошибке:
			    Serial.println("error opening log2.csv");
			  }
		}
	}


    // READ DATA
    Serial.print("DHT22, \t");

    uint32_t start = micros();
    int chk = DHT.read22(DHT22_PIN);
    uint32_t stop = micros();

    stat.total++;
    switch (chk)
    {
    case DHTLIB_OK:
        stat.ok++;
        Serial.print("OK,\t");
        break;
    case DHTLIB_ERROR_CHECKSUM:
        stat.crc_error++;
        Serial.print("Checksum error,\t");
        break;
    case DHTLIB_ERROR_TIMEOUT:
        stat.time_out++;
        Serial.print("Time out error,\t");
        break;
    case DHTLIB_ERROR_CONNECT:
        stat.connect++;
        Serial.print("Connect error,\t");
        break;
    case DHTLIB_ERROR_ACK_L:
        stat.ack_l++;
        Serial.print("Ack Low error,\t");
        break;
    case DHTLIB_ERROR_ACK_H:
        stat.ack_h++;
        Serial.print("Ack High error,\t");
        break;
    default:
        stat.unknown++;
        Serial.print("Unknown error,\t");
        break;
    }
    // DISPLAY DATA
    Serial.print(DHT.humidity, 1);
    Serial.print(",\t");
    Serial.print(DHT.temperature, 1);
    Serial.print(",\t");
    Serial.print(stop - start);
//    Serial.println();

    int percentage;
    float volts;
     
    
    volts = MGRead(MG_PIN);
    Serial.print( "SEN0159:" );
    Serial.print(volts); 
    Serial.print( "V           " );
     
    percentage = MGGetPercentage(volts,CO2Curve);
    Serial.print("CO2:");
    if (percentage == -1) {
        Serial.print( "<400" );
    } else {
        Serial.print(percentage);
    }
    Serial.print( "ppm" );  
    Serial.print( "       Time point:" );
    Serial.print(millis());
     
//    if (digitalRead(BOOL_PIN) ){
//        Serial.print( "=====BOOL is HIGH======" );
//    } else {
//        Serial.print( "=====BOOL is LOW======" );
//    }
    if (stat.total % 20 == 0)
    {
//        Serial.println("\nTOT\tOK\tCRC\tTO\tUNK");
//        Serial.print(stat.total);
//        Serial.print("\t");
//        Serial.print(stat.ok);
//        Serial.print("\t");
//        Serial.print(stat.crc_error);
//        Serial.print("\t");
//        Serial.print(stat.time_out);
//        Serial.print("\t");
//        Serial.print(stat.connect);
//        Serial.print("\t");
//        Serial.print(stat.ack_l);
//        Serial.print("\t");
//        Serial.print(stat.ack_h);
//        Serial.print("\t");
//        Serial.print(stat.unknown);
//        Serial.println("\n");

   	//Библиотека умеет определять, синхронизированы ли часы.
	if (timeStatus() == timeSet) {

	  // Открываем файл для записи. Только один файл
	  // может быть открыт одновременно
	  // вы можете закрыть файл, что бы открыть другой.
	  myFile = SD.open("log2.csv", FILE_WRITE);

	  // Если файл открылся, пишем в него:
	  if (myFile) {
//	    Serial.print("Writing to log2.csv...");
	   //Последовательно выводит часы, минуты, секунды
	   myFile.print(hour());
	   myFile.print(getDigits(minute()));
	   myFile.print(getDigits(second()));
	   myFile.print(" ");
	   //День, месяц и год
	   myFile.print(day());
	   myFile.print(" ");
	   myFile.print(month());
	   myFile.print(" ");
	   myFile.print(year());
	   myFile.print(",");
	    myFile.print(percentage);
	    myFile.print(",");
	    myFile.print(DHT.humidity);
	    myFile.print(",");
	    myFile.println(DHT.temperature);
	    // Закрываем файл:
	    myFile.close();
//	    Serial.println("done.");
	  } else {
	    // если файл не открылся, сообщает об ошибке:
//	    Serial.println("error opening csv.log");
	  }
	}

    }


	   Serial.print(hour());
	   Serial.print(getDigits(minute()));
	   Serial.print(getDigits(second()));
	   Serial.print(" ");
	   //День, месяц и год
	   Serial.print(day());
	   Serial.print(" ");
	   Serial.print(month());
	   Serial.print(" ");
	   Serial.print(year());
       
    Serial.print("\n");
     
    delay(200);
}
//
// END OF FILE
//
